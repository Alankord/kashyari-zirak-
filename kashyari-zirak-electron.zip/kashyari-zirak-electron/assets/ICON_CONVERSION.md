# Icon Conversion Instructions

## Windows (.ico)
1. Open icon.svg in a browser
2. Screenshot or use an online converter:
   - https://convertio.co/svg-ico/
   - https://cloudconvert.com/svg-to-ico
3. Save as: icon.ico (256x256 recommended)
4. Place in: assets/icon.ico

## macOS (.icns)
1. Convert SVG to PNG (1024x1024)
2. Use online converter:
   - https://convertio.co/png-icns/
3. Save as: icon.icns
4. Place in: assets/icon.icns

## Linux (PNG set)
Create these sizes in assets/icons/:
- 16x16.png
- 32x32.png
- 48x48.png
- 64x64.png
- 128x128.png
- 256x256.png
- 512x512.png

## Quick Online Converter
https://www.convertico.com/ (Drag & Drop SVG)
